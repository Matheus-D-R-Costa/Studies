package com.example.pessoasapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PessoasApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(PessoasApiApplication.class, args);
    }

}
