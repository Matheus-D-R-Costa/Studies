package com.example.pessoasapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PessoasApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
