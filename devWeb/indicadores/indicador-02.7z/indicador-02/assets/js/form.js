const saveButton = document.getElementById("btn-save-pessoa");

saveButton.addEventListener("click", () => {
  alert("Dados persistidos com sucesso!")
})